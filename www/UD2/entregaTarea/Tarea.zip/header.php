<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UD2 - Jorge Garea Rodriguez</title>
</head>
<body>

<header class="bg-primary text-white text-center py-3">
    <h1>UD2 - Jorge Garea Rodriguez</h1>
    <p>Descripción de la unidad</p>
</header>

</body>
</html>