<footer class="bg-dark text-white text-center py-3">
    <p class="mb-0">&copy; <?php echo date("Y"); ?> Jorge Garea Rodriguez. Todos los derechos reservados.</p>
</footer>