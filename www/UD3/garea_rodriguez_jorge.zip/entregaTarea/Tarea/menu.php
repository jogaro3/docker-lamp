<nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
    <div class="position-sticky">
        <ul class="nav flex-column">
            <!-- Opción Home -->
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                    Home
                </a>
            </li>
            <!-- Opción Inicializar Base de Datos -->
            <li class="nav-item">
                <a class="nav-link" href="init.php">
                    Inicializar Base de Datos
                </a>
            </li>
            <!-- Opción Nuevo Usuario -->
            <li class="nav-item">
                <a class="nav-link" href="nuevoUsuarioForm.php">
                    Nuevo Usuario
                </a>
            </li>
            <!-- Opción Lista de Usuarios -->
            <li class="nav-item">
                <a class="nav-link" href="usuarios.php">
                    Lista de Usuarios
                </a>
            </li>
            <!-- Opción Lista de Tareas -->
            <li class="nav-item">
                <a class="nav-link" href="tareas.php">
                    Lista de Tareas
                </a>
            </li>
            <!-- Opción Nueva Tarea -->
            <li class="nav-item">
                <a class="nav-link" href="nuevaForm.php">
                    Nueva Tarea
                </a>
            </li>
        </ul>
    </div>
</nav>