<footer class="bg-dark text-white text-center py-2">
    <p>© 2025 Jorge Garea Rodriguez - Todos los derechos reservados.</p>
</footer>