<header class="bg-primary text-white text-center py-3">
    <h1>Gestión de tareas</h1>
    <p>Tarea unidad 4 de DWCS</p>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3/dist/css/bootstrap.min.css" rel="stylesheet">
</header>